#include "stm32f10x.h"
#include "delay.h"
#include "usart.h"
#include "as608.h"
#include "OLED.h"
#include "esp8266.h"
#include "cJSON.h" 

/*
STM32F103		USB-TTL
PA9				RX
PA10			TX

STM32F103		AS608ָ��ģ��
PA2				RX
PA3				TX
PB0				WAK
*/

uint8_t handler_flag;

//????
extern unsigned char Weather_buff[300];
//????
Results Weather_results[] = {{0}};

/**************************************************************
����:�˵�
***************************************************************/
void menu(void)
{
	////printf("=============================\r\n");
	////printf("\t1-����ָ��\r\n");
	////printf("\t2-��ָ֤��\r\n");
	////printf("\t3-ɾ��ָ��\r\n");
	////printf("\t4-��ѯָ�Ƹ���\r\n");
	////printf("=============================\r\n");
}
int	KeyNum;
int  main()
{
	uint8_t ID = 0;
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);	//?????????
	usart1_init(57600);	//����1��ʼ�� ���ڴ�ӡ��Ϣ��������Ϣ
	Usart2_Init(115200);
	//usart2_init(57600);		//����2��ʼ�� ���ں�ָ��ģ��ͨ��
	OLED_Init();
	
	ESP8266_Init();
	
	Get_current_weather();
	
	//OLED_ShowString(1, 1, "ADD");

//	OLED_ShowChar(1, 1, 'A');
//	OLED_ShowString(1, 3, "HelloWorld!");
//	OLED_ShowNum(2, 1, 12345, 5);
//	OLED_ShowSignedNum(2, 7, -66, 2);
//	OLED_ShowHexNum(3, 1, 0xAA55, 4);
//	OLED_ShowBinNum(4, 1, 0xAA55, 16);
	as60x_wak_init();		//ָ��ģ���ʼ��
	//////printf("      --ָ��ģ��СDemo--\r\n");
	//menu();
	OLED_ShowString(1, 1, "ADD");
	OLED_ShowString(2, 1, "verify");
	OLED_ShowString(3, 1, "Delete");
	OLED_ShowString(4, 1, "search");

	
	
	
	
	
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7 | GPIO_Pin_6 | GPIO_Pin_5 | GPIO_Pin_4;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure1;
	GPIO_InitStructure1.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure1.GPIO_Pin = GPIO_Pin_0;
	GPIO_InitStructure1.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure1);
	
	

	GPIO_ResetBits(GPIOA, GPIO_Pin_0);
	cJSON_WeatherParse((char *)Weather_buff, Weather_results);
		
	OLED_ShowString(2, 8, Weather_results[0].now.text);
	OLED_ShowString(3, 8, Weather_results[0].now.temperature);
	while(1)
	{
		
		KeyNum = 0;
		if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_4) == 0)
		{
			delay_ms(20);
			while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_4) == 0);
			delay_ms(20);
			
			KeyNum = 1;		
		}
		if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_5) == 0)
		{
			delay_ms(20);
			while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_5) == 0);
			delay_ms(20);
			KeyNum = 2;
		}
		if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_6) == 0)
		{
			delay_ms(20);
			while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_6) == 0);
			delay_ms(20);
			KeyNum = 3;
		}
		if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_7) == 0)
		{
			delay_ms(20);
			while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_7) == 0);
			delay_ms(20);
			KeyNum = 4;
		}
		//OLED_ShowNum(4, 10, KeyNum, 1);
		ID=KeyNum;
		switch(KeyNum)
		{
			//����ָ��
			case 1:					
			SCANF:
				OLED_Clear();
				////printf("\t����ָ��\r\n");
				OLED_ShowString(1, 1, "add fingerprint");
				handler_flag = 0;
				ID = 0;
				////printf("������ID��(1~9)\r\n");
			  OLED_ShowString(2, 1, "INPUT:ID");
			  
				while(ID == 0)
				{	
					ID = KeyNum;
				}
				if(ID >0 && ID < 10)		
				{
					////printf("ID��:%d\r\n",ID);
					OLED_ShowString(3, 1, "ID=");
					OLED_ShowNum(3, 4, ID, 1);

				}
				
				
				else						goto SCANF;
					
				if(as608_add_fingerprint(ID))	
				{
					//////printf("����ָ��ʧ��\r\n");
					OLED_Clear();	
					OLED_ShowString(1, 1, "add fail");
				}
				else					
				{					
					//////printf("����ָ�Ƴɹ�\r\n");
					OLED_Clear();	
					OLED_ShowString(4, 1, "ADD SUCCESS");
				}
				handler_flag = 0;
				delay_ms(1000);
				OLED_Clear();	
				OLED_ShowString(1, 1, "ADD");
				OLED_ShowString(2, 1, "verify");
				OLED_ShowString(3, 1, "Delete");
				OLED_ShowString(4, 1, "search");
				menu();
				break;
			//��ָ֤��
			case 2:
				OLED_Clear();	
				////printf("\t��ָ֤��\r\n");
				OLED_ShowString(1, 1, "verify fingerprint");
				as608_verify_fingerprint();
				handler_flag = 0;
				menu();
				delay_ms(1000);
				GPIO_ResetBits(GPIOA, GPIO_Pin_0);
				OLED_Clear();	
				OLED_ShowString(1, 1, "ADD");
				OLED_ShowString(2, 1, "verify");
				OLED_ShowString(3, 1, "Delete");
				OLED_ShowString(4, 1, "search");
				break;	
			//ɾ��ָ��
			case 3:
				OLED_Clear();	
				////printf("\tɾ��ָ��\r\n");
				OLED_ShowString(1, 1, "delete fingerprint");
				as608_delete_fingerprint();	
				handler_flag = 0;	
				menu();
				delay_ms(1000);
				OLED_Clear();	
				OLED_ShowString(1, 1, "ADD");
				OLED_ShowString(2, 1, "verify");
				OLED_ShowString(3, 1, "Delete");
				OLED_ShowString(4, 1, "search");
				break;			
			//��ѯģ�����
			case 4:
				OLED_Clear();	
				////printf("\t�鿴ָ�Ƹ���\r\n");
				as608_find_fingerprints_num();
				handler_flag = 0;					
				menu();
				delay_ms(1000);
				OLED_Clear();	
				OLED_ShowString(1, 1, "ADD");
				OLED_ShowString(2, 1, "verify");
				OLED_ShowString(3, 1, "Delete");
				OLED_ShowString(4, 1, "search");
				break;
		}
	} 
	
}





/**************************************************************
����:ָ��ģ��WAK�����ⲿ�жϷ�����
***************************************************************/
void EXTI0_IRQHandler(void)
{
	if(EXTI_GetITStatus(EXTI_Line0) != RESET) //��������ⲿ�ж�
	{
		finger_status = FINGER_EXIST;
	}
	
	EXTI_ClearFlag(EXTI_Line0); //�����־λ
}

/**************************************************************
����:����2�жϷ����� ����ָ��ģ������
***************************************************************/
void USART1_IRQHandler(void)
{ 
	if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)//���յ�����
	{	 
		as608_receive_data[as608_receive_count] = USART_ReceiveData(USART1);
		as608_receive_count++;
	}  				 											 
}   



///**************************************************************
//����:����1�жϷ����� 
//***************************************************************/
//void USART2_IRQHandler(void)
//{ 
//	if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)//���յ�����
//	{	 
//		handler_flag = USART_ReceiveData(USART1);
//	}  				 											 
//}


/*���������ŵ�ƽ����ϣ��ߺ���2�����ŵĸߵ͵�ƽ�źŶ�Ӧcase1-case4��stm32�����жϲ���oled����ʾ��ǰ�����Ƿ�ɹ�*/

