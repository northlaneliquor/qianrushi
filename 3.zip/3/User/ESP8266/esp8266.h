#ifndef __ESP8266_H
#define __ESP8266_H
#include "stdio.h"	



#define REV_OK		0	//������ɱ�־
#define REV_WAIT	1	//����δ��ɱ�־

#define USART_DEBUG		USART1

//��������
unsigned char *ESP8266_GetIPD_GET(unsigned short timeOut,u8 *buff);

void ESP8266_Clear(void);
_Bool ESP8266_WaitRecive(void);

_Bool ESP8266_WaitRecive(void);

_Bool ESP8266_SendCmd(char *cmd, char *res);
void ESP8266_SendData(unsigned char *data, unsigned short len);

void ESP8266_Init(void);
void Get_current_weather(void);

#endif
