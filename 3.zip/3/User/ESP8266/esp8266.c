#include "stm32f10x.h"
#include "string.h"
#include "stdlib.h"
#include "esp8266.h"

#include "usart.h"
#include "delay.h"

//WIFI和密码
#define ESP8266_WIFI_INFO		"AT+CWJAP=\"vivo X100\",\"040509lyz\"\r\n"
//心知天气的API
#define Weather_TCP		"AT+CIPSTART=\"TCP\",\"api.seniverse.com\",80\r\n"
//心知天气GET报文
/*这里城市  恩施    语言为  英文*/
#define Weather_GET		"GET https://api.seniverse.com/v3/weather/now.json?key=SZq53kErUGUaDbXIf&location=nanjing&language=en&unit=c\r\n"

////������̨��ȡʱ���API
#define Time_TCP		"AT+CIPSTART=\"TCP\",\"quan.suning.com\",80\r\n"
////������̨��ȡʱ��GET����
#define Time_GET		"GET http://quan.suning.com/getSysTime.do"


//ESP8266数据存放
unsigned char esp8266_buf[300] = {0};
unsigned short esp8266_cnt = 0, esp8266_cntPre = 0;
//存放天气数据
unsigned char Weather_buff[300];   //位数是随机确定的
//���ʱ������
unsigned char Time_buff[100];   //λ�������ȷ����



/**************************************************************************/
//函数作用：ESP8266_Init初始化函数
//函数名称：ESP8266_Init(void);
/**************************************************************************/
void ESP8266_Init(void)
{
		
	ESP8266_Clear();
	
 /*让WIFI推出透传模式*/
	while(ESP8266_SendCmd("+++", ""))  
	delay_ms(500);
	
	UsartPrintf(USART_DEBUG, "1.AT\r\n");
	while(ESP8266_SendCmd("AT\r\n", "OK"))
	delay_ms(500);
	
//
	//加一步ESP8266复位操作
	
	UsartPrintf(USART_DEBUG, "2.RST\r\n");
	ESP8266_SendCmd("AT+RST\r\n", "");
	delay_ms(500);
	ESP8266_SendCmd("AT+CIPCLOSE\r\n", "");
	delay_ms(500);
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	UsartPrintf(USART_DEBUG, "3.CWMODE\r\n");
	while(ESP8266_SendCmd("AT+CWMODE=1\r\n", "OK"))
		delay_ms(500);
	
	UsartPrintf(USART_DEBUG, "4.AT+CIPMUX\r\n");
	while(ESP8266_SendCmd("AT+CIPMUX=0\r\n", "OK"))
		delay_ms(500);
	
	UsartPrintf(USART_DEBUG, "5.CWJAP\r\n");
	while(ESP8266_SendCmd(ESP8266_WIFI_INFO, "WIFI GOT IP"))
	delay_ms(500);
	delay_ms(500);
	delay_ms(500);
	UsartPrintf(USART_DEBUG, "ESP8266_Init OK\r\n");
}



/*获取网络天气数据*/
/**************************************************************************/
//函数作用：获取心知天气函数
//函数名称：Get_current_weather(void)
/**************************************************************************/
void Get_current_weather(void)
{
	ESP8266_Clear();
	
  UsartPrintf(USART_DEBUG, "6.Weather_TCP OK\r\n");	
	while(ESP8266_SendCmd(Weather_TCP, "CONNECT"))
	delay_ms(500);
	delay_ms(500);
	
  UsartPrintf(USART_DEBUG, "7.AT+CIPMODE=1 OK\r\n");		
	while(ESP8266_SendCmd("AT+CIPMODE=1\r\n", "OK"))
	delay_ms(500);
	delay_ms(500);
	delay_ms(500);
/*sizeof(Weather_GET)，必须用sizeof函数，用strlen没有用*/ 	
	ESP8266_SendData((u8 *)Weather_GET, sizeof(Weather_GET)); //发送AT+CIPSEND  以及 Weather_GE
	
	ESP8266_GetIPD_GET(200,Weather_buff);
	ESP8266_Clear();//清除缓存数据	

	delay_ms(500);
	delay_ms(500);
	while(ESP8266_SendCmd("+++", ""))      /*退出透传模式*/
	delay_ms(500);
	UsartPrintf(USART_DEBUG, "+++ OK\r\n");	

	while(ESP8266_SendCmd("AT\r\n", "OK"))   //验证是否退出透传模式
		delay_ms(500);
	UsartPrintf(USART_DEBUG, "�˳�͸��ģʽ�ɹ���\r\n");
}

//时间
/**************************************************************************/
//函数作用：获取苏宁后台时间
//函数名称：Get_current_time();
/**************************************************************************/
//void Get_current_time(void)
//{
//	ESP8266_Clear();
//	
//  UsartPrintf(USART_DEBUG, "6.Time_TCP OK\r\n");	
//	while(ESP8266_SendCmd(Time_TCP, "CONNECT"))
//	delay_ms(500);
//	delay_ms(500);
//	
//  UsartPrintf(USART_DEBUG, "7.AT+CIPMODE=1 OK\r\n");		
//	while(ESP8266_SendCmd("AT+CIPMODE=1\r\n", "OK"))
//	delay_ms(500);
//	delay_ms(500);
//	delay_ms(500);
///*sizeof(Weather_GET)��������sizeof��������strlenû����*/  	
//	ESP8266_SendData((u8 *)Time_GET, sizeof(Time_GET)); //����AT+CIPSEND  �Լ� Weather_GET
//	
//	ESP8266_GetIPD_GET(200,Time_buff);  //����������ȡ����
//	ESP8266_Clear();//�����������	

//	delay_ms(500);
//	delay_ms(500);
//	while(ESP8266_SendCmd("+++", ""))      /*�˳�͸��ģʽ*/
//	delay_ms(500);
//	UsartPrintf(USART_DEBUG, "+++ OK\r\n");	

//	while(ESP8266_SendCmd("AT\r\n", "OK"))   //��֤�Ƿ��˳�͸��ģʽ
//		delay_ms(500);
//	UsartPrintf(USART_DEBUG, "1.AT\r\n");
//}




/**************************************************************************/
//函数作用：串口二中断函数
//函数名称：USART2_IRQHandler();
/**************************************************************************/
void USART2_IRQHandler(void)
{

	if(USART_GetITStatus(USART2, USART_IT_RXNE) != RESET) //接收中断
	{

		if(esp8266_cnt >= sizeof(esp8266_buf))	esp8266_cnt = 0; //防止串口被刷爆			
		esp8266_buf[esp8266_cnt++] = USART2->DR;  

//		USART_SendData(USART1,USART2->DR);      //让接收到的数据打印在串口一上
		
		USART_ClearFlag(USART2, USART_FLAG_RXNE);
	}
}



//==========================================================
//	函数名称：	ESP8266_Clear
//
//	函数功能：	清空缓存
//
//	入口参数：	无
//
//	返回参数：	无
//
//	说明：	
//==========================================================
void ESP8266_Clear(void)
{

	memset(esp8266_buf, 0, sizeof(esp8266_buf));
	esp8266_cnt = 0;

}
//==========================================================

//	函数名称：	ESP8266_WaitRecive
//
//	函数功能：	等待接收完成
//
//	入口参数：	无
//
//	返回参数：	REV_OK-接收完成		REV_WAIT-接收超时未完成
//
//	说明：		循环调用检测是否接收完成
//==========================================================
_Bool ESP8266_WaitRecive(void)
{

	if(esp8266_cnt == 0) 							//如果接收计数为0 则说明没有处于接收数据中，所以直接跳出，结束函数
		return REV_WAIT;
		
	if(esp8266_cnt == esp8266_cntPre)				//如果上一次的值和这次相同，则说明接收完毕
	{
		esp8266_cnt = 0;							//清0接收计数
			
		return REV_OK;								//返回接收完成标志
	}
		
	esp8266_cntPre = esp8266_cnt;					//置为相同
	
	return REV_WAIT;								//返回接收未完成标志

}




//==========================================================
//  函数名称：	ESP8266_GetIPD
//
//	函数功能：	copy天气数据到Weather_buff数组里面
//
//	返回参数：	平台返回的原始数据
//
//	说明：		copy天气数据到Weather_buff
//==========================================================

unsigned char *ESP8266_GetIPD_GET(unsigned short timeOut,u8 *buff)//这里我用了一个全局变量将esp8266buf储存到这个全局变量里面
{
	do
	{
		delay_ms(5);													
	} while(timeOut--);
	strcpy((char*)buff,(char*)esp8266_buf);
	return buff;														
}

/*还未用到*/
//==========================================================
//	函数名称：	ESP8266_GetIPD
//
//	函数功能：	获取平台返回的数据
//
//	入口参数：	等待的时间(乘以10ms)
//
//	返回参数：	平台返回的原始数据
//
//	说明：		不同网络设备返回的格式不同，需要去调试
//				如ESP8266的返回格式为	"+IPD,x:yyy"	x代表数据长度，yyy是数据内容
//==========================================================

unsigned char *ESP8266_GetIPD(unsigned short timeOut)
{

	char *ptrIPD = NULL;
	
	do
	{
		if(ESP8266_WaitRecive() == REV_OK)								//����������
		{
			ptrIPD = strstr((char *)esp8266_buf, "IPD,");				//������IPD��ͷ
			if(ptrIPD == NULL)											//���û�ҵ���������IPDͷ���ӳ٣�������Ҫ�ȴ�һ�ᣬ�����ᳬ���趨��ʱ��
			{
				//UsartPrintf(USART_DEBUG, "\"IPD\" not found\r\n");
			}
			else
			{
				ptrIPD = strchr(ptrIPD, ':');							//�ҵ�':'
				if(ptrIPD != NULL)
				{
					ptrIPD++;
					return (unsigned char *)(ptrIPD);
				}
				else
					return NULL;
				
			}
		}
		
		delay_ms(5);													//��ʱ�ȴ�
	} while(timeOut--);
	
	return NULL;														//��ʱ��δ�ҵ������ؿ�ָ��

}
//==========================================================
//	函数名称：	ESP8266_SendCmd
//
//	函数功能：	发送命令
//
//	入口参数：	cmd：命令
//				res：需要检查的返回指令
//
//	返回参数：	0-成功	1-失败
//
//	说明：			
//==========================================================
_Bool ESP8266_SendCmd(char *cmd, char *res)
{
	
	unsigned char timeOut = 250;

	Usart_SendString(USART2, (unsigned char *)cmd, strlen((const char *)cmd));
	
	while(timeOut--)
	{
		if(ESP8266_WaitRecive() == REV_OK)							//如果收到数据
		{		
			if(strstr((const char *)esp8266_buf, res) != NULL)		//如果检索到关键词
			{
				ESP8266_Clear();									//清空缓存
				
				return 0;
			}
		}
		
		delay_ms(10);
	}
	
	return 1;

}

//==========================================================
//	函数名称：	ESP8266_SendData
//
//	函数功能：	发送数据
//
//	入口参数：	data：数据
//				len：长度
//
//	返回参数：	无
//
//	说明：		
//==========================================================
void ESP8266_SendData(unsigned char *data, unsigned short len)
{

	char cmdBuf[32];
	
	ESP8266_Clear();								//清空接收缓存
	sprintf(cmdBuf, "AT+CIPSEND\r\n");		//发送命令
	if(!ESP8266_SendCmd(cmdBuf, ">"))				//收到‘>’时可以发送数据
	{
		UsartPrintf(USART_DEBUG, "8.AT+CIPSEND\r\n");
		/*发送请求数据*/
		Usart_SendString(USART2, data, len);		/*发送请求数据*/		
	}
}


